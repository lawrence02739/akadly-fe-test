import { ChevronRight, Filter, Plus, Search, X } from "lucide-react";
import { useCallback, useEffect, useState } from "react";
import type { FormEvent } from "react";
import toast from "react-hot-toast";
import { Link } from "react-router-dom";
import {
  adminError,
  ticketsApi,
  type TicketCategory,
  type TicketModule,
  type TicketPriority,
  type TenantPlanContext,
  type TicketRecord,
  type TicketStatus,
} from "../api/tickets.api";

const statuses: Record<TicketStatus, string> = {
  open: "Open",
  assigned: "Assigned",
  in_progress: "In progress",
  waiting_for_user: "Waiting for user",
  pending: "Pending",
  escalated: "Escalated",
  resolved: "Resolved",
  closed: "Closed",
};
const colors: Record<TicketStatus, string> = {
  open: "bg-rose-50 text-rose-700",
  assigned: "bg-blue-50 text-blue-700",
  in_progress: "bg-indigo-50 text-indigo-700",
  waiting_for_user: "bg-amber-50 text-amber-700",
  pending: "bg-amber-50 text-amber-700",
  escalated: "bg-fuchsia-50 text-fuchsia-700",
  resolved: "bg-emerald-50 text-emerald-700",
  closed: "bg-slate-100 text-slate-600",
};
const modules: Array<{
  value: TicketModule;
  label: string;
  category: TicketCategory;
  issues: string[];
}> = [
  {
    value: "courses",
    label: "Courses",
    category: "course_access",
    issues: [
      "Course access",
      "Course content",
      "Lesson or video",
      "Assessment",
    ],
  },
  {
    value: "forms",
    label: "Forms",
    category: "technical",
    issues: ["Form access", "Form submission", "Form response"],
  },
  {
    value: "payments",
    label: "Payments",
    category: "payment",
    issues: ["Payment status", "Invoice", "Billing date"],
  },
  {
    value: "account",
    label: "Account",
    category: "other",
    issues: ["User access", "Workspace settings", "Other"],
  },
];
const blank = {
  title: "",
  description: "",
  module: "courses" as TicketModule,
  category: "course_access" as TicketCategory,
  issueType: "Course access",
  priority: "medium" as TicketPriority,
  relatedEntityType: "",
  referenceUrl: "",
};

export default function TicketsListPage() {
  const [items, setItems] = useState<TicketRecord[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [status, setStatus] = useState<TicketStatus | "">("");
  const [priority, setPriority] = useState<TicketPriority | "">("");
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [modal, setModal] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState("");
  const [form, setForm] = useState(blank);
  const [files, setFiles] = useState<File[]>([]);
  const [planContext, setPlanContext] = useState<TenantPlanContext | null>(null);
  const [planContextError, setPlanContextError] = useState(false);
  const load = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const result = await ticketsApi.list({
        page,
        pageSize: 20,
        status: status || undefined,
        priority: priority || undefined,
        search: search || undefined,
      });
      setItems(result.items);
      setTotal(result.pagination.total);
    } catch (e) {
      setError(adminError(e));
    } finally {
      setLoading(false);
    }
  }, [page, priority, search, status]);
  useEffect(() => {
    void load();
  }, [load]);
  const submit = async (event: FormEvent) => {
    event.preventDefault();
    setSubmitting(true);
    try {
      const attachments = await Promise.all(
        files.map((file) => ticketsApi.presignAttachment(file)),
      );
      const ticket = await ticketsApi.create({ ...form, attachments });
      setSubmitted(ticket.ticketNumber);
      setForm(blank);
      setFiles([]);
      await load();
      toast.success("Issue sent to support");
    } catch (e) {
      toast.error(adminError(e));
    } finally {
      setSubmitting(false);
    }
  };
  const selected = modules.find((item) => item.value === form.module)!;
  const pages = Math.max(1, Math.ceil(total / 20));
  return (
    <section className="mx-auto max-w-7xl space-y-6 p-5 sm:p-8">
      <header className="flex flex-col justify-between gap-4 md:flex-row md:items-end">
        <div>
          <p className="text-sm font-semibold text-[#0C5A69]">
            Help and support
          </p>
          <h1 className="mt-1 text-2xl font-bold">My tickets</h1>
          <p className="mt-1 text-sm text-slate-500">
            Raise issues and track updates from the support team.
          </p>
        </div>
        <div className="flex flex-wrap gap-2"><Link to="/partner/tickets/dashboard" className="inline-flex items-center justify-center rounded-lg border border-[#0C5A69] px-4 py-2.5 text-sm font-semibold text-[#0C5A69]">Ticket dashboard</Link><button
            onClick={() => {
              setSubmitted("");
              setModal(true);
              setPlanContextError(false);
              void ticketsApi.context().then(setPlanContext).catch(() => {
                setPlanContext(null);
                setPlanContextError(true);
              });
            }}
            className="inline-flex items-center justify-center gap-2 rounded-lg bg-[#0C5A69] px-4 py-2.5 text-sm font-semibold text-white"
          >
            <Plus size={17} /> Raise an issue
          </button></div>
      </header>
      <section className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
        <div className="grid gap-3 border-b border-slate-100 p-4 lg:grid-cols-[1fr_auto_auto]">
          <label className="relative">
            <Search
              size={16}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
            />
            <input
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                setPage(1);
              }}
              className="w-full rounded-lg border border-slate-200 py-2 pl-9 pr-3 text-sm"
              placeholder="Search ticket number or issue..."
            />
          </label>
          <select
            value={status}
            onChange={(e) => {
              setStatus(e.target.value as TicketStatus | "");
              setPage(1);
            }}
            className="rounded-lg border px-3 py-2 text-sm"
          >
            <option value="">All statuses</option>
            {Object.entries(statuses).map(([value, label]) => (
              <option key={value} value={value}>
                {label}
              </option>
            ))}
          </select>
          <select
            value={priority}
            onChange={(e) => {
              setPriority(e.target.value as TicketPriority | "");
              setPage(1);
            }}
            className="rounded-lg border px-3 py-2 text-sm"
          >
            <option value="">All priorities</option>
            {["low", "medium", "high", "critical", "urgent"].map((value) => (
              <option key={value}>{value}</option>
            ))}
          </select>
        </div>
        {loading ? (
          <State text="Loading tickets…" />
        ) : error ? (
          <State text={error} retry={load} />
        ) : (
          <>
            <div className="overflow-x-auto">
              <table className="min-w-[760px] w-full text-left text-sm">
                <thead className="bg-slate-50 text-xs uppercase text-slate-500">
                  <tr>
                    <th className="p-4">Ticket</th>
                    <th className="p-4">Module / issue</th>
                    <th className="p-4">Status</th>
                    <th className="p-4">Priority</th>
                    <th className="p-4">Updated</th>
                    <th className="p-4" />
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {items.map((ticket) => (
                    <tr key={ticket.id}>
                      <td className="p-4">
                        <Link
                          to={`/partner/tickets/${ticket.id}`}
                          className="font-bold text-[#0C5A69]"
                        >
                          #{ticket.ticketNumber}
                        </Link>
                        <p className="mt-1 max-w-sm truncate text-slate-700">
                          {ticket.title}
                        </p>
                      </td>
                      <td className="p-4 text-slate-600">
                        {ticket.module} · {ticket.issueType}
                      </td>
                      <td className="p-4">
                        <span
                          className={`rounded-full px-2.5 py-1 text-xs font-bold ${colors[ticket.status]}`}
                        >
                          {statuses[ticket.status]}
                        </span>
                      </td>
                      <td className="p-4 capitalize">{ticket.priority}</td>
                      <td className="p-4 text-slate-500">
                        {new Date(ticket.updatedAt).toLocaleString()}
                      </td>
                      <td className="p-4">
                        <Link to={`/partner/tickets/${ticket.id}`}>
                          <ChevronRight size={18} />
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {items.length === 0 && (
              <State text="No tickets found. Raise an issue to contact support." />
            )}
          </>
        )}
        <div className="flex items-center justify-between border-t p-4 text-sm text-slate-500">
          <span>
            Page {page} of {pages} · {total} tickets
          </span>
          <div className="flex gap-2">
            <button
              disabled={page === 1}
              onClick={() => setPage(page - 1)}
              className="rounded border px-3 py-1.5 disabled:opacity-40"
            >
              Previous
            </button>
            <button
              disabled={page >= pages}
              onClick={() => setPage(page + 1)}
              className="rounded border px-3 py-1.5 disabled:opacity-40"
            >
              Next
            </button>
          </div>
        </div>
      </section>
      {modal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/45 p-4"
          onMouseDown={() => setModal(false)}
        >
          <form
            className="max-h-[92vh] w-full max-w-2xl overflow-y-auto rounded-2xl bg-white p-6 shadow-2xl"
            onMouseDown={(e) => e.stopPropagation()}
            onSubmit={submit}
          >
            {submitted ? (
              <div className="py-10 text-center">
                <h2 className="text-xl font-bold">Issue submitted</h2>
                <p className="mt-2 text-sm">
                  Your support ticket <b>{submitted}</b> is open.
                </p>
                <button
                  type="button"
                  onClick={() => setModal(false)}
                  className="mt-6 rounded-lg bg-[#0C5A69] px-4 py-2 text-white"
                >
                  Done
                </button>
              </div>
            ) : (
              <>
                <div className="flex justify-between">
                  <div>
                    <h2 className="text-xl font-bold">Raise an issue</h2>
                    <p className="mt-1 text-sm text-slate-500">
                      Give support enough detail to route it correctly.
                    </p>
                  </div>
                  <button type="button" onClick={() => setModal(false)}>
                    <X />
                  </button>
                </div>
                <div className="mt-6 space-y-4">
                  <PlanContextCard context={planContext} unavailable={planContextError} />
                  <Field label="Issue title">
                    <input
                      required
                      value={form.title}
                      onChange={(e) =>
                        setForm({ ...form, title: e.target.value })
                      }
                    />
                  </Field>
                  <section>
                    <p className="text-sm font-semibold">Module</p>
                    <p className="mt-1 text-xs text-slate-500">
                      Choose where the issue occurred.
                    </p>
                    <div className="mt-3 grid gap-3 sm:grid-cols-2">
                      {modules.map((item) => (
                        <button
                          key={item.value}
                          type="button"
                          onClick={() =>
                            setForm({
                              ...form,
                              module: item.value,
                              category: item.category,
                              issueType: item.issues[0],
                              relatedEntityType: "",
                            })
                          }
                          className={`rounded-xl border p-4 text-left ${form.module === item.value ? "border-[#0C5A69] bg-teal-50 ring-1 ring-[#0C5A69]" : "border-slate-200 hover:border-teal-300"}`}
                        >
                          <span className="block font-bold text-slate-800">
                            {form.module === item.value ? "? " : ""}
                            {item.label}
                          </span>
                          <span className="mt-1 block text-xs text-slate-500">
                            {item.issues.join(", ")}
                          </span>
                        </button>
                      ))}
                    </div>
                  </section>
                  <section>
                    <p className="text-sm font-semibold">
                      Issue type in {selected.label}
                    </p>
                    <p className="mt-1 text-xs text-slate-500">
                      Select the exact issue for correct support routing.
                    </p>
                    <div className="mt-3 grid gap-3 sm:grid-cols-2">
                      {selected.issues.map((issue) => (
                        <button
                          key={issue}
                          type="button"
                          onClick={() => setForm({ ...form, issueType: issue })}
                          className={`rounded-xl border p-4 text-left ${form.issueType === issue ? "border-[#0C5A69] bg-teal-50 ring-1 ring-[#0C5A69]" : "border-slate-200 hover:border-teal-300"}`}
                        >
                          <span className="block font-bold text-slate-800">
                            {form.issueType === issue ? "? " : ""}
                            {issue}
                          </span>
                          <span className="mt-1 block text-xs text-slate-500">
                            Support will see this issue type.
                          </span>
                        </button>
                      ))}
                    </div>
                  </section>
                  <Field label="Priority">
                    <select
                      value={form.priority}
                      onChange={(e) =>
                        setForm({
                          ...form,
                          priority: e.target.value as TicketPriority,
                        })
                      }
                    >
                      {["low", "medium", "high", "critical", "urgent"].map(
                        (value) => (
                          <option key={value}>{value}</option>
                        ),
                      )}
                    </select>
                  </Field>
                  <Field label="Related course, form, payment, or account item">
                    <input
                      value={form.relatedEntityType}
                      onChange={(e) =>
                        setForm({ ...form, relatedEntityType: e.target.value })
                      }
                      placeholder="Optional context"
                    />
                  </Field>
                  <Field label="Describe the issue">
                    <textarea
                      required
                      rows={5}
                      value={form.description}
                      onChange={(e) =>
                        setForm({ ...form, description: e.target.value })
                      }
                    />
                  </Field>
                  <Field label="Affected page URL">
                    <input
                      type="url"
                      value={form.referenceUrl}
                      onChange={(e) =>
                        setForm({ ...form, referenceUrl: e.target.value })
                      }
                      placeholder="Paste the page link where the issue happened"
                    />
                    <p className="mt-1 text-xs font-normal text-slate-500">
                      Optional. Copy the browser URL and paste it here.
                    </p>
                  </Field>
                  <section>
                    <p className="text-sm font-semibold">
                      Screenshots or files{" "}
                      <span className="font-normal text-slate-500">
                        (optional)
                      </span>
                    </p>
                    <p className="mt-1 text-xs text-slate-500">
                      Upload up to 5 images or documents, maximum 10 MB each.
                    </p>
                    <label className="mt-3 flex cursor-pointer flex-col items-center justify-center rounded-xl border-2 border-dashed border-slate-200 bg-slate-50 p-5 text-center hover:border-[#0C5A69]">
                      <span className="font-semibold text-[#0C5A69]">
                        Choose files
                      </span>
                      <span className="mt-1 text-xs text-slate-500">
                        PNG, JPG, PDF, DOCX or TXT
                      </span>
                      <input
                        className="sr-only"
                        type="file"
                        multiple
                        accept="image/png,image/jpeg,application/pdf,.doc,.docx,text/plain"
                        onChange={(event) => {
                          const selected = Array.from(event.target.files ?? []);
                          const valid = selected.filter(
                            (file) => file.size <= 10 * 1024 * 1024,
                          );
                          if (valid.length !== selected.length)
                            toast.error("Each file must be 10 MB or smaller");
                          setFiles((current) =>
                            [...current, ...valid].slice(0, 5),
                          );
                          event.currentTarget.value = "";
                        }}
                      />
                    </label>
                    {files.length > 0 && (
                      <ul className="mt-3 space-y-2">
                        {files.map((file, index) => (
                          <li
                            key={file.name + index}
                            className="flex items-center justify-between rounded-lg border border-slate-200 px-3 py-2 text-sm"
                          >
                            <span className="truncate">
                              {file.name}{" "}
                              <span className="text-slate-400">
                                ({Math.ceil(file.size / 1024)} KB)
                              </span>
                            </span>
                            <button
                              type="button"
                              onClick={() =>
                                setFiles((current) =>
                                  current.filter(
                                    (_, fileIndex) => fileIndex !== index,
                                  ),
                                )
                              }
                              className="ml-3 text-rose-600"
                            >
                              Remove
                            </button>
                          </li>
                        ))}
                      </ul>
                    )}
                  </section>
                </div>
                <div className="mt-6 flex justify-end gap-3">
                  <button
                    type="button"
                    onClick={() => setModal(false)}
                    className="rounded-lg border px-4 py-2"
                  >
                    Cancel
                  </button>
                  <button
                    disabled={submitting}
                    className="rounded-lg bg-[#0C5A69] px-4 py-2 text-white disabled:opacity-50"
                  >
                    {submitting ? "Submitting…" : "Submit issue"}
                  </button>
                </div>
              </>
            )}
          </form>
        </div>
      )}
    </section>
  );
}
function PlanContextCard({ context, unavailable }: { context: TenantPlanContext | null; unavailable: boolean }) {
  if (!context && !unavailable) return <section className="rounded-xl border border-slate-200 bg-slate-50 p-4 text-sm text-slate-500">Loading current plan and usage…</section>;
  if (!context) return <section className="rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900">Your plan information is temporarily unavailable. You can still raise this issue.</section>;
  const limit = (value: number | null) => value === null ? "Unlimited" : String(value);
  const plan = context.plan;
  return <section className="rounded-xl border border-teal-200 bg-teal-50 p-4">
    <div className="flex flex-wrap items-start justify-between gap-2"><div><p className="text-xs font-bold uppercase tracking-wide text-[#0C5A69]">Workspace plan context</p><h3 className="mt-1 font-bold text-slate-900">{plan?.name ?? "Plan not assigned"}</h3><p className="mt-1 text-xs text-slate-600">Support will receive this plan and usage context with your ticket.</p></div><span className="rounded-full bg-white px-2.5 py-1 text-xs font-semibold capitalize text-slate-700">{context.paymentStatus ?? "payment unknown"}</span></div>
    {plan ? <div className="mt-4 grid gap-2 sm:grid-cols-2"><Usage label="Users" value={`${context.usage.users} / ${limit(plan.limits.users)}`} /><Usage label="Courses" value={`${context.usage.courses} / ${limit(plan.limits.courses)}`} /><Usage label="Students" value={`Limit: ${limit(plan.limits.students)}`} /><Usage label="Content storage" value={`Limit: ${limit(plan.limits.contentBytes)}`} /></div> : <p className="mt-3 text-sm text-slate-600">Ask support to confirm or assign the workspace plan.</p>}
  </section>;
}
function Usage({ label, value }: { label: string; value: string }) { return <div className="rounded-lg border border-teal-100 bg-white px-3 py-2"><p className="text-xs text-slate-500">{label}</p><p className="mt-0.5 text-sm font-bold text-slate-800">{value}</p></div>; }
function Field({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <label className="block text-sm font-semibold">
      {label}
      <span className="mt-2 block [&_input]:w-full [&_input]:rounded-lg [&_input]:border [&_input]:border-slate-200 [&_input]:px-3 [&_input]:py-2 [&_select]:w-full [&_select]:rounded-lg [&_select]:border [&_select]:border-slate-200 [&_select]:px-3 [&_select]:py-2 [&_textarea]:w-full [&_textarea]:rounded-lg [&_textarea]:border [&_textarea]:border-slate-200 [&_textarea]:p-3">
        {children}
      </span>
    </label>
  );
}
function State({ text, retry }: { text: string; retry?: () => void }) {
  return (
    <div className="p-10 text-center text-sm text-slate-500">
      <Filter className="mx-auto mb-3 text-slate-300" size={26} />
      <p>{text}</p>
      {retry && (
        <button
          onClick={retry}
          className="mt-3 rounded border px-3 py-1.5 text-[#0C5A69]"
        >
          Retry
        </button>
      )}
    </div>
  );
}
